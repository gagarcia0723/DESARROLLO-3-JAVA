public class Garcia_158_proy1 {

   DetectorPeces detector = new DetectorPeces();
   
   public static void main(String[] args){
     
      new Garcia_158_proy1();
   
   } 

   Garcia_158_proy1(){
      
      detector.menuInicial();
      
   }
}



























